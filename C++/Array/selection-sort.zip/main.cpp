/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>

using namespace std;

int main()
{
    int n;
    cin>>n;
    
    int arr[100];
    
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    
   int counter=1;
     while(counter<n){
         for(int i=0;i<n-counter;i++){
             if(arr[i]>arr[i+1]){
                 int temp = arr[i];
                 arr[i]=arr[i+1];
                 arr[i+1]=temp;
             }
             
         }
   counter++;  }
    
    for(int i=0;i<n;i++){
        cout<<arr[i]<<"  ";
        
    }
    cout<<endl;

    return 0;
}
